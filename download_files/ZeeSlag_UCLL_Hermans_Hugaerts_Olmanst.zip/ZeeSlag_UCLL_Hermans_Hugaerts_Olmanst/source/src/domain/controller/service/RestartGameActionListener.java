package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import domain.controller.Controller;

/**
 * @author Nathan Olmanst r0594509
 */
public class RestartGameActionListener implements ActionListener {
	private Controller controller;
	
	public RestartGameActionListener(Controller controller) {
		this.controller = controller;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		this.controller.restartGame();
	}
}
