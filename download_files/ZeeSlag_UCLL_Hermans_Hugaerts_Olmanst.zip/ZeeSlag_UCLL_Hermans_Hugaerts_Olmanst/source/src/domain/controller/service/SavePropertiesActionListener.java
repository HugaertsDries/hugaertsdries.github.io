package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

import domain.controller.Controller;
import domain.view.PropertiesPanel;


/**
 * @author Dries Hugaerts r0629197
 */
public class SavePropertiesActionListener implements ActionListener{

private Controller c;
	
	public SavePropertiesActionListener(Controller c) {
		this.c = c;
	}
	
	@Override
	public void actionPerformed(ActionEvent action) {
		JButton b = (JButton) action.getSource();
		PropertiesPanel p = (PropertiesPanel) b.getParent();
		String placeStrategy = p.getPlaceStrategy();
		String attackStrategy = p.getAttackStrategy();
		c.setStrategies(attackStrategy, placeStrategy);
		c.closeProperties();
	}

}
