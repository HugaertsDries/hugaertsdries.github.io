package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;

import domain.controller.Controller;
import domain.model.ShipTypes;

/**
 * @author Dries Hugaerts r0629197
 */
public class ShipActionListener implements ActionListener {
	
	private Controller c;
	
	public ShipActionListener(Controller c){
		this.c = c;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void actionPerformed(ActionEvent e) {
		JComboBox combo = (JComboBox)e.getSource();
        String ship = (String)combo.getSelectedItem();
        c.setPropertieShip(ShipTypes.valueOf(ship.toUpperCase()));
	}

}
