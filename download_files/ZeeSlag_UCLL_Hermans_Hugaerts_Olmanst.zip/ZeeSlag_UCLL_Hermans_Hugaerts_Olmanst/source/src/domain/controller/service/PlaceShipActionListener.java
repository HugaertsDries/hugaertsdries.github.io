package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import domain.controller.Controller;
import domain.model.BoardTile;
/**
 * @author Dries Hugaerts r0629197
 */
public class PlaceShipActionListener implements ActionListener {
	
	private Controller c;
	
	public PlaceShipActionListener(Controller c){
		this.c = c;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		BoardTile b = (BoardTile) e.getSource();
		c.placeShip(b);
	}
}
