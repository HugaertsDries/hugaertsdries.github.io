package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;

import domain.controller.Controller;
import domain.model.Alignment;
import domain.view.AlignmentControlPanel;

/**
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */

public class AlignmentActionListener implements ActionListener {
	
	private Controller c;
	
	public AlignmentActionListener(Controller c){
		this.c = c;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JCheckBox check = (JCheckBox)e.getSource();
		AlignmentControlPanel a = (AlignmentControlPanel) check.getParent();
		String allignment = check.getText();
		
		if(allignment.equals("Horizontaal") && a.getVertiacal().isSelected()){
			this.c.setPropertieAlignment(Alignment.HORIZONTAL);
			a.getVertiacal().setSelected(false);
		} else if (allignment.equals("Horizontaal") && !a.getVertiacal().isSelected()){
			this.c.setPropertieAlignment(Alignment.HORIZONTAL);
			a.getHorizontal().setSelected(true);
		} else if (allignment.equals("Verticaal") && a.getHorizontal().isSelected()) {
			this.c.setPropertieAlignment(Alignment.VERTICAL);
			a.getHorizontal().setSelected(false);
		} else {
			this.c.setPropertieAlignment(Alignment.VERTICAL);
			a.getVertiacal().setSelected(true);
		}
	}
}
