package domain.controller.service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import domain.controller.Controller;
import domain.view.AlignmentControlPanel;

/**
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class StartGameActionListener implements ActionListener {
	private Controller c;
	
	public StartGameActionListener(Controller c) {
		this.c = c;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (this.c.startGameState()) {
			JButton b = (JButton)e.getSource();
			AlignmentControlPanel acp = (AlignmentControlPanel) b.getParent();
			acp.changeButtonVisibility(false);
		}
	}
}
