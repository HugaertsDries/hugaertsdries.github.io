package domain.controller;

import domain.model.Alignment;
import domain.model.BoardTile;
import domain.model.EndGameException;
import domain.model.GameBoard;
import domain.model.ModelException;
import domain.model.Player;
import domain.model.ShipTypes;
import domain.model.ZeeSlag;
import domain.model.service.FileStorage;
import domain.view.UIFacade;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class Controller {
	private UIFacade ui;
	private ZeeSlag zeeslag;

	public Controller() {
		ui = new UIFacade(this);
	}

	public void startGame() {
		ui.getStartScreen();
	}
	
	/**
	 * Reset all model variables
	 * || then
	 * update the UI by giving them the new boardTiles
	 * || then
	 * update the player scores
	 */
	public void restartGame() {
		this.zeeslag.resetGame();
		this.ui.redrawGameBoards(this.zeeslag.getAiTiles(), this.zeeslag.getHumanTiles());
		this.ui.updateScores();
	}

	public void getGameBoard(Player p) {
		this.zeeslag = new ZeeSlag(p);
		ui.getGameBoardScreen();
	}
	
	public int getAiScore() {
		return this.zeeslag.getAiScore();
	}
	
	public int getHumanScore() {
		return this.zeeslag.getHumanScore();
	}

	public GameBoard getAiGameBoard() {
		return this.zeeslag.getAiGameBoard();
	}

	public GameBoard getHumanGameBoard() {
		return this.zeeslag.getHumanGameBoard();
	}

	public void placeShip(BoardTile tile) throws ModelException {
		try {
			this.zeeslag.placeShip(tile);
		} catch (ModelException e) {
			this.ui.getInfoScreen(e.getMessage());
		}
	}

	/**
	 * attack a boardTile and Update all the player's score
	 */
	public void attackShip(BoardTile tile) throws ModelException {
		try {
			this.zeeslag.attackAIShip(tile);
		} catch (EndGameException eg) {
			this.ui.getEndGameScreen(eg.getMessage());
		} catch (ModelException e) {
			this.ui.getInfoScreen(e.getMessage());
		}
		
		this.ui.updateScores();
	}

	/**
	 * Indirectly called by the UI to update the selected ship alignment
	 */
	public void setPropertieAlignment(Alignment alignment) {
		try {
			this.zeeslag.setPropertieAlignment(alignment);
		} catch (ModelException e) {
			this.ui.getInfoScreen(e.getMessage());
		}

	}

	/**
	 * Indirectly called by the UI to update the selected ship type
	 */
	public void setPropertieShip(ShipTypes ship) {
		this.zeeslag.setPropertieShip(ship);
	}

	
	public void setStrategies(String attackStrategy, String placementStrategy) {
		try {
			this.zeeslag.setStrategies(attackStrategy, placementStrategy);
		} catch (ModelException e) {
			this.ui.getInfoScreen(e.getMessage());
		}
	}
	
	public boolean startGameState() {
		boolean successfull = false;
		try {
			this.zeeslag.getCurrentState().startGame();
			successfull = true;
		} catch (ModelException e) {
			this.ui.getInfoScreen(e.getMessage());
		}
		return successfull;
	}

	public void getProperties() {
		this.ui.getProperties();
	}

	public void closeProperties() {
		this.ui.closeProperties();
	}

	/**
	 * @return primitive array with attackStrategy at index 0 and placeStrategy at index 1
	 */
	public String[] getSavedAIProperties() {
		return new String[]{FileStorage.getInstance().load("attackStrategy"), FileStorage.getInstance().load("placeStrategy")};
	}
}
