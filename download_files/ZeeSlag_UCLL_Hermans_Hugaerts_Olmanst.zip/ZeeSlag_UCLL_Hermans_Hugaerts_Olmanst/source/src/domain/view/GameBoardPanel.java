package domain.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import domain.controller.Controller;
import domain.controller.service.AttackShipActionListener;
import domain.controller.service.PlaceShipActionListener;
import domain.model.BoardTile;
import domain.model.GameBoard;
import domain.model.HumanPlayer;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class GameBoardPanel extends JPanel implements BasicPanel {
	private static final long serialVersionUID = 1L;
	
	List<BoardTile> buttons;
	JLabel player;
	private final String NAME;
	private static final String FONTNAME = "Arial";
	private static final int FONTSIZE = 16;
	//private GameBoard gameboard;
	private Controller controller;
	private Boolean isHuman;

	public GameBoardPanel(GameBoard gameboard, Controller controller) {
		//this.gameboard = gameboard;
		this.setIsHuman(gameboard);
		this.controller = controller;
		NAME = gameboard.getPlayer().getName();
		//player = new JLabel(NAME);
		buttons = gameboard.getbuttons();
		this.setUp();
	}

	public void resetBoard(List<BoardTile> boardTiles) {
		buttons = boardTiles;
		this.removeAll();
		this.setUp();
	}
	
	private void setIsHuman(GameBoard gameboard) {
		this.isHuman = gameboard.getPlayer() instanceof HumanPlayer;
	}

	@Override
	public void setUp() {
		//LAYOUT PANEL
		this.setLayout( new GridBagLayout());
		this.setBorder(new LineBorder(Color.white, 5));
		//LABEL LAYOUT
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;

		// TODO: FIX HARDCODED MAX SCORE
		this.addLabel(NAME + " ( 19 ): ");
		//this.player.setPreferredSize(new Dimension(/*WAS 400 - CENTER THE TILES*/ 20, 20));
		
		//ADDING BUTTONS
		for(BoardTile b : this.buttons){
				c.gridwidth = 1;
				int[] p = b.getPosition();
				c.gridx = p[0];
				c.gridy = p[1] + 1;
				if(isHuman) {
					b.addActionListener(new PlaceShipActionListener(this.controller));
				} else {
					b.addActionListener(new AttackShipActionListener(this.controller));
				}
				this.add(b, c);
		}
	}
	
	private void addLabel(String string) {
		
		this.player = new JLabel(string);
		
		
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;

		player.setFont(new Font(FONTNAME, Font.PLAIN, FONTSIZE));
		c.gridwidth = 11; // take full width of 1st row
		c.gridx = 0;
		c.gridy = 0;
		//ADD LABEL TO PANEL
		this.add(player, c);
		this.revalidate();
	}
	
	public void changeScore(int score) {
		
		this.remove(player); // Remove old label
		this.addLabel(NAME + " ( " + score + " ): ");
		
	}
	
	public List<BoardTile> getTiles() {
		return this.buttons;
	}


	public List<BoardTile> getButtons(){
		return this.buttons;
	}
	
	public GameBoardFrame getFrameOf(){
		return (GameBoardFrame) this.getParent();
	}
}
