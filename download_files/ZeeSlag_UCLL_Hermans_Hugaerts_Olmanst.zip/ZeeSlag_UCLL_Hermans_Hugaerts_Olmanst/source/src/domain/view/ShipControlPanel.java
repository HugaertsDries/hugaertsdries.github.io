package domain.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import domain.controller.Controller;
import domain.controller.service.ShipActionListener;
import domain.model.ShipTypes;

/**
 * @author Dries Hugaerts r0629197
 */
public class ShipControlPanel extends JPanel implements BasicPanel{

	private static final long serialVersionUID = 1L;
	private static final String fontName = "Arial";
	private static final int FONTSIZE = 16;
	
	private JLabel label;
	private JComboBox<String> comboBox;
	private Controller controller;

	
	public ShipControlPanel(Controller controller){
		this.controller = controller;
		String[] list = {ShipTypes.CARRIER.toString(), ShipTypes.BATTLESHIP.toString(), ShipTypes.SUBMARINE.toString(), ShipTypes.DESTROYER.toString(), ShipTypes.PATROL_SHIP.toString()};
		label = new JLabel("Beschikbare schepen: ");
		comboBox = new JComboBox<String>(list);
		this.setUp();
		
	}
	
	@Override
	public void setUp() {
		//LAYOUT PANEL
		this.setLayout(new GridBagLayout());
		this.setBorder(BorderFactory.createMatteBorder(0, 0, 5, 0, Color.WHITE));
		//LAYOUT LABEL
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		label.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(25, 20, 0, 0);
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 0;
		//ADD LABEL TO PANEL
		this.add(label, c);
		//LAYOUT COMBOBOX
		comboBox.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(-75, 30, 0, 30);
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1;
		c.weighty = 0.5;
		//ADD ACTIONLISTENER
		comboBox.addActionListener(new ShipActionListener(this.controller));
		//ADD COMBOBOX TO PANEL
		this.add(comboBox, c);
	}
	
	public JComboBox<String> getComboBox() {
		return comboBox;
	}
}
