package domain.view;

import java.util.List;

import javax.swing.JButton;

import domain.controller.Controller;
import domain.model.BoardTile;
import domain.model.GameBoard;
import domain.view.StartScreenFrame;
import domain.view.StartScreenPanel;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class UIFacade {

	private StartScreenFrame start;
	private GameBoardFrame gameBoard;
	private SmallSimpleFrame random;
	private EndGameFrame endGameFrame;
	private PropertiesFrame properties;
	private Controller controller;
	
	public UIFacade(Controller controller){
		this.controller = controller;
		this.start = new StartScreenFrame(new StartScreenPanel(this.controller));
	}
	
	public void getStartScreen(){
		this.start.setVisible(true);
	}
	
	public GameBoardFrame getGameBoardFrame() {
		return this.gameBoard;
	}
	
	public void getGameBoardScreen(){
		if(this.start.isVisible() == true){
			this.start.setVisible(false);
			this.setGameBoardFrame();
			this.gameBoard.setVisible(true);
		}
	}

	private void setGameBoardFrame() {
		this.gameBoard = new GameBoardFrame(new GameBoardPanel(this.controller.getHumanGameBoard(), this.controller), new GameBoardPanel(this.controller.getAiGameBoard(), this.controller), this.controller);
	}
	
	public void redrawGameBoards(List<BoardTile> aiBoardTiles, List<BoardTile> humanBoardTiles) {
		this.gameBoard.getPanel_AI().resetBoard(aiBoardTiles);
		this.gameBoard.getPanel_Player().resetBoard(humanBoardTiles);
		enableButtons();
	}
	
	public void getInfoScreen(String message){
		if (this.random != null) {
			this.random.dispose();
		}
		this.random = new SmallSimpleFrame(new InfoPanel(message), "Info");
		this.random.setVisible(true);
	}
	
	public void getEndGameScreen(String message) {
		this.endGameFrame = new EndGameFrame(new EndGamePanel(controller, message), "Game Over");
		this.endGameFrame.setVisible(true);
		
	}
	
	private void enableButtons() {
		this.endGameFrame.dispose();
		ControlPanel ctrlP = (ControlPanel) this.gameBoard.getPanel_Controll();
		ctrlP.getAllignmentPanel().changeButtonVisibility(true);
	}
	
	public void updateScores() {
		this.getGameBoardFrame().getPanel_Player().changeScore(this.controller.getHumanScore());
		this.getGameBoardFrame().getPanel_AI().changeScore(this.controller.getAiScore());
	}

	public void getProperties() {
		this.properties = new PropertiesFrame(new PropertiesPanel(this.controller));
		this.properties.setVisible(true);
	}

	public void closeProperties() {
		this.properties.setVisible(false);
	}
}
