package domain.view;

/**
 * @author Dries Hugaerts r0629197
 */
public interface BasicFrame {

	public void setUp();
}
