package domain.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Dries Hugaerts r0629197
 */
public class SmallSimpleFrame extends JFrame implements BasicFrame {

	private static final long serialVersionUID = 1L;
	private JPanel random;
	
	public SmallSimpleFrame(JPanel random, String title){
		//SET UP
		this.setRandomPane(random);
		this.setTitle(title);
		this.setUp();
	}

	private void setRandomPane(JPanel random) {
		if(random == null){
			throw new UIException("Er moet een panel worden meegegeven");
		}else{
			this.random = random;
		}
	}

	@Override
	public void setUp() {
		this.setLayout(new GridLayout(1, 1));
		random.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));
		//SET SIZE
		this.setSize(new Dimension (420,150));
		this.setResizable(false);
		//CLOSE ONLY THIS FRAME
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//CENTER SCREEN
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		this.add(this.random);
	}

}
