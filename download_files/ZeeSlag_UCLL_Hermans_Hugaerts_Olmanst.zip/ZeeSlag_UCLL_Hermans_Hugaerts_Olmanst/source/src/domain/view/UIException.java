package domain.view;

/**
 * @author Dries Hugaerts r0629197
 */
public class UIException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	
	public UIException(String e){
		super(e);
	}
}
