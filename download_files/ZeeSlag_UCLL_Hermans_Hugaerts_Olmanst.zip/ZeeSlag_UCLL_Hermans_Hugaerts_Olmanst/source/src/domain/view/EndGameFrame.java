package domain.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class EndGameFrame  extends JFrame implements BasicFrame {


	private static final long serialVersionUID = 1L;
	private JPanel endGamePanel;
	
	public EndGameFrame(JPanel panel, String title){
		//SET UP
		this.setPanel(panel);
		this.setTitle(title);
		this.setUp();
	}


	@Override
	public void setUp() {
		this.setLayout(new GridLayout(1, 1));
		endGamePanel.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));
		//SET SIZE
		this.setSize(new Dimension (400,200));
		this.setResizable(false);
		//CLOSE ONLY THIS FRAME
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//CENTER SCREEN
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		this.add(this.endGamePanel);
	}

	private void setPanel(JPanel panel) {
			if(panel == null){
				throw new UIException("Er moet een panel worden meegegeven");
			}else{
				this.endGamePanel = panel;
			}
		}
}
		
