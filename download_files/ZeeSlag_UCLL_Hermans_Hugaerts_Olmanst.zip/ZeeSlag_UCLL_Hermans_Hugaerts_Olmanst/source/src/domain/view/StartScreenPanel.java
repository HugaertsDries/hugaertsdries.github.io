package domain.view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import domain.controller.Controller;
import domain.controller.service.StartScreenActionListener;

/**
 * @author Dries Hugaerts r0629197
 */
public class StartScreenPanel extends JPanel implements BasicPanel {

	private static final long serialVersionUID = 1L;
	private static final String FONTNAME = "Arial";
	private static final int FONTSIZE = 16;
	
	JLabel label;
	JTextField text;
	JButton button;
	
	public StartScreenPanel(Controller controller){
		this.label = new JLabel("Name: ");
		this.text = new JTextField("", 8);
		this.button = new JButton("Start");
		this.button.addActionListener(new StartScreenActionListener(controller));
		this.setUp();
	}

	@Override
	public void setUp() {
		//LAYOUT PANEL
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		//ADD LABEL
		label.setFont(new Font(FONTNAME, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(0, 0, 0, 5);
		this.add(label, c);
		//ADD TEXT
		text.setFont(new Font(FONTNAME, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(0, 5, 0, 5);
		text.setPreferredSize(new Dimension(200,24));
		this.add(text, c);
		//ADD BUTTON
		button.setFont(new Font(FONTNAME, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(0, 5, 0, 0);
		this.add(button, c);
	}
	
	public String getText(){
		return this.text.getText();
	}
	
}
