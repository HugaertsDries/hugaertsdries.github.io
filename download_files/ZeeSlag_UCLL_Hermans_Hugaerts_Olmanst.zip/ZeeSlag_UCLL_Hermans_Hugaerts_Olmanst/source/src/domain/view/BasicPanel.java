package domain.view;

/**
 * @author Dries Hugaerts r0629197
 */
public interface BasicPanel{

	/**
	 * Used to define UI aspects of a JPanel instance
	 */
	public void setUp();
}
