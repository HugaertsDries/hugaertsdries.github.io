package domain.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Dries Hugaerts r0629197
 */
public class StartScreenFrame extends JFrame implements BasicFrame {

	private static final long serialVersionUID = 1L;
	private JPanel start;
	
	public StartScreenFrame(JPanel start){
		//SET UP
		this.setStartPane(start);
		this.setUp();
	}

	public void setUp() {
		this.setLayout(new GridLayout(1, 1));
		start.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));
		this.setTitle("Kies een naam");
		//SET SIZE
		this.setSize(new Dimension (350,150));
		this.setResizable(false);
		//CLOSE
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//CENTER SCREEN
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		this.add(this.start);
	}

	private void setStartPane(JPanel start) {
		if(start == null){
			throw new UIException("Er moet een start panel worden meegegeven");
		}else{
			this.start = start;
		}
	}
}
