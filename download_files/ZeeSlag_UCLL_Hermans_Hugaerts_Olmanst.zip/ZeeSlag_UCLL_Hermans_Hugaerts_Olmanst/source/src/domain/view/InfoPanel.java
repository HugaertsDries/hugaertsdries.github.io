package domain.view;


import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author Dries Hugaerts r0629197
 */
public class InfoPanel extends JPanel implements BasicPanel {

	private static final long serialVersionUID = 1L;
	private JLabel infoText;
	private JLabel image;

	public InfoPanel(String message) {
		this.setInfoText(message);
		this.setImage();
		this.setUp();
	}

	@Override
	public void setUp() {
		// LAYOUT PANEL
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		//ADD IMAGE
		c.insets = new Insets(0, 0, 0, 10);
		c.gridx = 0;
		c.gridy = 0;
		this.add(image, c);
		//ADD INFOTEXT
		c.insets = new Insets(0, 5, 0, 10);
		c.gridx = 1;
		c.gridy = 0;
		//c.gridwidth = 2;
		this.add(infoText,c);
	
	}

	private void setImage() {
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File("resources/Icons/info.png"));
			
		} catch (IOException e) {
			System.out.println("Afbeelding niet gevonden");
		}
		Image resize = img.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
		image = new JLabel(new ImageIcon(resize));
	}

	private void setInfoText(String message) {
		
		if(message == null || message.isEmpty()){
			throw new UIException("Message mag niet leeg zijn!");
		}
		
		this.infoText = new JLabel(message);
	}

}
