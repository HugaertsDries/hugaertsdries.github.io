package domain.view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import domain.controller.Controller;

/**
 * @author Dries Hugaerts r0629197
 */
public class ControlPanel extends JPanel implements BasicPanel{

	private static final long serialVersionUID = 1L;
	JPanel ships;
	JPanel allignment;
	Controller controller;
	
	public ControlPanel(Controller controller){
		this.controller = controller;
		ships = new ShipControlPanel(this.controller);
		allignment = new AlignmentControlPanel(this.controller);
		this.setUp();
	}
	
	@Override
	public void setUp() {
		//LAYOUT PANEL
		this.setLayout(new GridLayout(2, 1));
		this.setSize(420,420);
		this.setBorder(new LineBorder(Color.white, 5));
		//ADDING PANELS
		this.add(ships);
		this.add(allignment);
	}
	
	public ShipControlPanel getShipPanel() {
		return (ShipControlPanel) this.ships;
	}
	
	public AlignmentControlPanel getAllignmentPanel() {
		return (AlignmentControlPanel) this.allignment;
	}
}
