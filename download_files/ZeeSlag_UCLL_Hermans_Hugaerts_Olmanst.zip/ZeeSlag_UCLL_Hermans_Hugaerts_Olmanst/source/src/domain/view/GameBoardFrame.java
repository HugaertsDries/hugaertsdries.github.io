package domain.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import domain.controller.Controller;

/**
 * @author Dries Hugaerts r0629197
 */
public class GameBoardFrame extends JFrame implements BasicFrame {
	
	private static final long serialVersionUID = 1L;
	private GameBoardPanel player;
	private GameBoardPanel AI;
	private JPanel controll;
	
	public GameBoardFrame(GameBoardPanel board_1, GameBoardPanel board_2, Controller controller){
		this.player = board_1;
		this.AI = board_2;
		this.controll = new ControlPanel(controller);
		this.setUp();
		
	}
	
	public void setUp (){
		//LAYOUT FRAME
		this.setTitle("Zeeslag");
		this.setSize(new Dimension (1200,450));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Center screen
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		//Set size
		this.setResizable(false);
		this.setLayout(new GridLayout(1, 3));
		
		
		/**
		 * 
		 
		this.setSize(new Dimension (1200,660));
		this.setLayout(new GridBagLayout());


		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		//c.gridheight = 449;
		//c.gridwidth = 11; // take full width of 1st row
		c.gridx = 0;
		c.gridy = 0;
		c.insets = new Insets(10, 0, 0, 0);
		//ADD LABEL TO PANEL
		this.add(controll, c);
		c.gridx = 200;
		c.gridy = 0;
		this.add(player, c);
		c.gridx = 500;
		c.gridy = 0;
		this.add(AI, c);
		c.anchor = GridBagConstraints.LAST_LINE_START;
		c.gridx = 0;
		c.gridy = 450;
		c.gridwidth = 1200;
		JPanel jf = new JPanel();
		jf.setSize(1200, 200);
		jf.setBorder(new LineBorder(Color.white, 5));
		this.add(jf, c);
		*/
		
		this.add(controll);
		this.add(player);
		this.add(AI);
	}
	
	public GameBoardPanel getPanel_AI() {
		return this.AI;
	}
	
	public GameBoardPanel getPanel_Player() {
		return this.player;
	}
	
	public JPanel getPanel_Controll() {
		return this.controll;
	}
}
