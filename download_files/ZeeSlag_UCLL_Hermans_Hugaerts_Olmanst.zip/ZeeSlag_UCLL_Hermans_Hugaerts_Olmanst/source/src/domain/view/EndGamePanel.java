package domain.view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import domain.controller.Controller;
import domain.controller.service.RestartGameActionListener;

/**
 * @author Nathan Olmanst r0594509
 */
public class EndGamePanel extends JPanel implements BasicPanel {

	private static final long serialVersionUID = 1L;
	private static final String FONTNAME = "Arial";
	private static final int FONTSIZE = 16;
	
	private Controller controller;
	private JLabel messageLabel;
	private JButton restartGameButton;
	
	public EndGamePanel(Controller controller, String message) {
		this.controller = controller;
		setMessage(message);
		this.restartGameButton = new JButton("Restart game");
		this.setUp();
	}
	
	@Override
	public void setUp() {
		// LAYOUT PANEL
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		//ADD LABEL
		messageLabel.setFont(new Font(FONTNAME, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 0;
		this.add(messageLabel, c);
		//ADD ACTIONLISTENER
		restartGameButton.addActionListener(new RestartGameActionListener(this.controller));
		//ADD BUTTON
		this.restartGameButton.setPreferredSize(new Dimension(100, 40));
		c.insets = new Insets(5,10,1,10);
		c.gridy = 4;
		//c.gridwidth = 2;
		this.add(restartGameButton,c);
	}

	private void setMessage(String message) {
		if (message == null) {
			throw new UIException("EndGamePanel requires a message to be displayed");
		}
		this.messageLabel = new JLabel(message);
	}
}
