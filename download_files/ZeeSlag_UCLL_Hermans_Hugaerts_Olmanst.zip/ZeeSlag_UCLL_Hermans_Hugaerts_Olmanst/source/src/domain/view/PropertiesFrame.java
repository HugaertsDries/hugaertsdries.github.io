package domain.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author Dries Hugaerts r0629197
 */
public class PropertiesFrame extends JFrame implements BasicFrame {

	private static final long serialVersionUID = 1L;
	private JPanel properties;
	
	public PropertiesFrame(JPanel properties) {
		// SET UP
		this.setPropertiesPane(properties);
		this.setUp();
	}

	@Override
	public void setUp() {
		this.setLayout(new GridLayout(1, 1));
		properties.setBorder(BorderFactory.createEmptyBorder(40,40,40,40));
		this.setTitle("Properties");
		//SET SIZE
		this.setSize(new Dimension (300,300));
		this.setResizable(false);
		//CLOSE ONLY THIS FRAME
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//CENTER SCREEN
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		this.add(this.properties);
	}
	
	private void setPropertiesPane(JPanel properties){
		if(properties == null){
			throw new UIException("The properties frame can not be null");
		}
		
		this.properties = properties;
	}

}
