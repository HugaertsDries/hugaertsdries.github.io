package domain.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import domain.controller.Controller;
import domain.controller.service.GetPropertiesActionListener;
import domain.controller.service.StartGameActionListener;

/**
 * @author Dries Hugaerts r0629197
 */
public class AlignmentControlPanel extends JPanel implements BasicPanel {
	
	private static final long serialVersionUID = 1L;
	private static final String fontName = "Arial";
	private static final int FONTSIZE = 16;
	
	private JLabel label;
	//private Checkbox horizontal;
	//private Checkbox vertical;
	private JCheckBox horizontal;
	private JCheckBox vertical;
	private JButton start;
	private JButton properties;
	Controller controller;
	
	public AlignmentControlPanel(Controller controller) {
		this.controller = controller;
		label = new JLabel("Richting: ");
		horizontal = new JCheckBox("Horizontaal", true);
		vertical = new JCheckBox("Verticaal", false);
		this.start = new JButton("Start game");
		this.properties = new JButton("Properties");
		this.setUp();
	}

	@Override
	public void setUp() {
		//LAYOUT PANEL
		this.setLayout(new GridBagLayout());
		this.setBorder(BorderFactory.createMatteBorder(5, 0, 0, 0, Color.WHITE));
		//lAYOUT LABEL
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		label.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(25, 20, 0, 0);
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 0;
		this.add(label, c);
		//LAYOUT CHECKBOX H		
		horizontal.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1;
		c.weighty = 1;
		//ACTIONLISTENER
		horizontal.addActionListener(new domain.controller.service.AlignmentActionListener(this.controller));
		this.add(horizontal, c);
		//LAYOUT CHECKBOX V
		vertical.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.gridx = 3;
		c.gridy = 1;
		c.weightx = 1;
		c.weighty = 1;
		//ACTIONLISTENER
		vertical.addActionListener(new domain.controller.service.AlignmentActionListener(this.controller));
		this.add(vertical, c);
		//LAYOUT START BUTTON
		start.setPreferredSize(new Dimension(100, 40));
		c.insets = new Insets(10,10,5,10);
		c.gridx = 0;
		c.gridy = 2;
		c.weighty = 1;
		start.addActionListener(new StartGameActionListener(this.controller));
		this.add(start, c);
		//LAYOUT PROPERTIES BUTTON
		properties.setPreferredSize(new Dimension(100, 40));
		c.insets = new Insets(10,10,5,10);
		c.gridx = 3;
		c.gridy = 2;
		c.weighty = 1;
		this.properties.addActionListener(new GetPropertiesActionListener(this.controller));
		this.add(this.properties, c);
		
		
	}
	
	public void changeButtonVisibility(boolean bool) {
		this.start.setEnabled(bool);
		this.properties.setEnabled(bool);
	}
	
	public JButton getPropertiesButton() {
		return this.properties;
	}

	public JCheckBox getHorizontal(){
		return this.horizontal;
	}
	
	public JCheckBox getVertiacal(){
		return this.vertical;
	}
}
