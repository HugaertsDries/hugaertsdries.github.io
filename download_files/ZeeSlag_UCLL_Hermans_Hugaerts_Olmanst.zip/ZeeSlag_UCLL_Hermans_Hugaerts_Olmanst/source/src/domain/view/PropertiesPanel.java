package domain.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import domain.controller.Controller;
import domain.controller.service.SavePropertiesActionListener;


/**
 * @author Dries Hugaerts r0629197
 */
public class PropertiesPanel extends JPanel implements BasicPanel {

	private static final long serialVersionUID = 1L;
	private static final String fontName = "Arial";
	private static final int FONTSIZE = 16;
	private JLabel place;
	private JComboBox<String> placeStrategies;
	private JLabel attack;
	private JComboBox<String> attackStrategies;
	private JButton save;
	private Controller controller;
	
	private String[] placeStrategiesArray = {"Easy", "Hard"};
	private String[] attackStrategiesArray = {"Easy", "Hard"};
	
	
	public PropertiesPanel(Controller c){
		this.controller = c;
		this.fillComboBoxValues();
		this.place = new JLabel("Kies een leg strategie: ");
		this.placeStrategies = new JComboBox<String>(placeStrategiesArray);
		this.attack = new JLabel("Kies een aanval strategie: ");
		this.attackStrategies = new JComboBox<String>(attackStrategiesArray);
		save = new JButton("Save");
		this.setUp();
	}

	@Override
	public void setUp() {
		this.setLayout(new GridBagLayout());
		this.setBorder(BorderFactory.createMatteBorder(5, 0, 0, 0, Color.WHITE));
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		//LAYOUT LABEL
		place.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 0;
		this.add(place, c);
		//LAYOUT COMBOBOX
		placeStrategies.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 1;
		this.add(placeStrategies, c);
		//LAYOUT LABEL
		attack.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 2;
		this.add(attack, c);
		//LAYOUT COMBOBOX
		attackStrategies.setFont(new Font(fontName, Font.PLAIN, FONTSIZE));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 3;
		this.add(attackStrategies, c);
		//LAYOUT BUTTON
		save.setPreferredSize(new Dimension(100, 40));
		c.insets = new Insets(5,10,5,10);
		c.gridy = 4;

		save.addActionListener(new SavePropertiesActionListener(this.controller));

		this.add(save, c);
	}

	public String getPlaceStrategy() {
		return (String) this.placeStrategies.getSelectedItem();
	}

	public String getAttackStrategy() {
		return (String) this.attackStrategies.getSelectedItem();
	}

	private void fillComboBoxValues() {
		
		String[] savedValues = this.controller.getSavedAIProperties();
		
		this.attackStrategiesArray = new String[]{savedValues[0], savedValues[0].equals("Hard") ? "Easy" : "Hard"};
		this.placeStrategiesArray = new String[]{savedValues[1], savedValues[1].equals("Hard") ? "Easy" : "Hard"};
	}
}
