package domain.model;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public abstract class Player {
	
	protected String name;
	protected GameBoard gameBoard;
	private int playerScore = 19;

	public Player(String name) {
		setName(name);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		if(name == null || name.isEmpty()){
			throw new ModelException("name is null", null);
		}
		this.name = name;
	}

	public void setDoubleAssociation(GameBoard gameBoard) {
		this.gameBoard = gameBoard;
	}
	
	public int getPlayerScore() {
		return this.playerScore;
	}
	
	public void lowerPlayerScore() {
		this.playerScore -= 1;	
	}
	
	public void ResetPlayer() {
		this.playerScore = 19;
	}
}
