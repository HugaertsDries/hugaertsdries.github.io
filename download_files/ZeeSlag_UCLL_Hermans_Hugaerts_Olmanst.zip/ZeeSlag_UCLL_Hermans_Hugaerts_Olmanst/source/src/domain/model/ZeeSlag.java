package domain.model;

import java.util.List;

import domain.model.service.FileStorage;
import domain.model.state.EndedGameState;
import domain.model.state.GameState;
import domain.model.state.SetupGameState;
import domain.model.state.StartedGameState;
import domain.model.strategy_ai.AttackStrategy;
import domain.model.strategy_ai.AttackStrategyFactory;
import domain.model.strategy_ai.AttackStrategyType;
import domain.model.strategy_ai.PlacementStrategy;
import domain.model.strategy_ai.PlacementStrategyFactory;
import domain.model.strategy_ai.PlacementStrategyType;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 * 
 * @info World class
 */
public class ZeeSlag implements AI_Useable{

	private Properties properties;
	private GameBoard humanGameBoard;
	private GameBoard aiGameBoard;
	
	private GameState startedState;
	private GameState endedState;
	private GameState setupState;
	private GameState currentState;
	
	private FileStorage file;
	
	private AttackStrategy attackStrategy;
	private PlacementStrategy placeStrategy;

	public ZeeSlag(Player humanPlayer) {
		this.setHumanGameBoard(humanPlayer);
		this.setAiGameBoard(new AIPlayer("Computer", this));
		
		// FILE STORAGE
		file = FileStorage.getInstance();
		try {
			PlacementStrategyType placementStrategyValue = PlacementStrategyType.valueOf(file.load("placeStrategy").toUpperCase());
			placeStrategy = PlacementStrategyFactory.createStrategy(placementStrategyValue.getClassName());
			
			AttackStrategyType attackStrategyValue = AttackStrategyType.valueOf(file.load("attackStrategy").toUpperCase());
			attackStrategy = AttackStrategyFactory.createStrategy(attackStrategyValue.getClassName(), this);
			
		} catch (Exception e) {
			throw new ModelException(e.getMessage(), e);
		}
		
		((AIPlayer) this.getAiGameBoard().getPlayer()).setNewPlacementStrategy(placeStrategy);
		((AIPlayer) this.getAiGameBoard().getPlayer()).setNewAttacktStrategy(attackStrategy);
		
		this.properties = new Properties();
		
		this.startedState = new StartedGameState(this);
		this.setupState = new SetupGameState(this);
		this.endedState = new EndedGameState(this);
		this.currentState = this.setupState;
		
	}

	// ===================================================== Getters/Setters
	// =========================================================

	public void setCurrentState(GameState state) {
		this.currentState = state;
	}
	
	public GameState getCurrentState() {
		return this.currentState;
	}
	
	public GameState getStartedState() {
		if(this.humanGameBoard.getRemainingShipsToPlace() == 0){
		return this.startedState;
		}else{
			throw new ModelException("U moet nog " + this.humanGameBoard.getRemainingShipsToPlace() + " schepen plaatsen voor U het spel mag starten", null);
		}
	}
	
	public GameState getEndedState() {
		return endedState;
	}
	
	public GameState getSetupState() {
		return this.setupState;
	}
	
	public GameBoard getAiGameBoard() {
		return aiGameBoard;
	}

	public void setAiGameBoard(AIPlayer AIPlayer) {
		this.aiGameBoard = new GameBoard(AIPlayer);
	}

	public GameBoard getHumanGameBoard() {
		return humanGameBoard;
	}

	public void setHumanGameBoard(Player humanPlayer) {
		this.humanGameBoard = new GameBoard(humanPlayer);
	}

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	// ========================================================== LOGIC
	// ==============================================================

	/**
	 *  Indirectly called by the UI to set the requested AI logic strategies
	 */
	public void setStrategies(String attackStrategy, String placementStrategy) {
		this.getCurrentState().setStrategies(attackStrategy, placementStrategy);
	}
	
	/**
	 * Indirectly called by the UI to request a ship to be placed on the
	 * humanGameBoard.
	 */
	public void placeShip(BoardTile tile) throws ModelException {
		this.getCurrentState().placeShip(tile);
	}
	
	/**
	 * Indirectly called by the UI to request a hit to be registered on the
	 * aiGameBoard.
	 * 
	 * Will cause the AI to shoot once and will check if the game has ended.
	 */
	public void attackAIShip(BoardTile tile) throws ModelException {
		this.getCurrentState().attackShip(tile);
	}
	
	/**
	 * Indirectly called by AttackAIShip(...)
	 * || Causes the AI to attack the board of the other player.
	 * @returns true if the AI hit a ship.
	 */
	@Override
	public boolean attackHumanShip(int tileIndex) throws ModelException {		
		return this.getHumanGameBoard().attackShip(this.getHumanGameBoard().getbuttons().get(tileIndex));
	}

	/**
	 * Indirectly called by the UI to update the selected ship alignment
	 */
	public void setPropertieAlignment(Alignment alignment) {
		this.properties.setAlignment(alignment);
	}

	/**
	 * Indirectly called by the UI to update the selected ship type
	 */
	public void setPropertieShip(ShipTypes ship) {
		this.properties.setShip(ship);
	}

	/**
	 * @return a copy of a list of buttons to the UI classes
	 */
	// TODO: make GameBoard return a copy
	public List<BoardTile> getHumanTiles() {
		return this.getHumanGameBoard().getbuttons();
	}

	/**
	 * @return a copy of a list of buttons to the UI classes
	 */
	// TODO: make GameBoard return a copy
	public List<BoardTile> getAiTiles() {
		return this.getAiGameBoard().getbuttons();
	}
	
	/**
	 * @return the human player's score;
	 */
	public int getHumanScore() {
		return this.getHumanGameBoard().getPlayer().getPlayerScore();
	}
	
	/**
	 * @return the ai player's score;
	 */
	public int getAiScore() {
		return this.getAiGameBoard().getPlayer().getPlayerScore();
	}
	
	public void startAI() {
		((AIPlayer) this.getAiGameBoard().getPlayer()).setUp();
	}
		
	public void revealBoards() {
		if (!this.getCurrentState().equals(this.getEndedState())) {
			throw new IllegalStateException();
		}
		
		this.getAiGameBoard().revealBoard();
		//this.getHumanGameBoard().revealBoard();
	}

	public void resetGame() {
		this.getCurrentState().setupGame();
		for(ShipTypes s:  ShipTypes.values()){
			s.reset();
		}
	}
}
