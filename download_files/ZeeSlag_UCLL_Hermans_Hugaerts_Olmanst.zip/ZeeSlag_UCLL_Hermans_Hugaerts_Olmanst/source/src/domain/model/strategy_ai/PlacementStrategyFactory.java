package domain.model.strategy_ai;

import domain.model.ModelException;

/**
 * @author Cedric Hermans r0449493
 * @author Nathan Olmanst r0594509
 */
public class PlacementStrategyFactory {
	
	/**
	 * @return an instance of class PlacementStrategy
	 */
	public static PlacementStrategy createStrategy(String strategyType) {
		PlacementStrategy instance = null;
		
		try{
			Class<?> aClass = Class.forName(strategyType);
			instance = (PlacementStrategy) aClass.newInstance();
		}
		catch (Exception ex){
			throw new ModelException(ex.getMessage(), ex);
		}
		return instance;
	}
}
