package domain.model.strategy_ai;

/**
 * @author Nathan Olmanst r0594509
 */
public enum AttackStrategyType {

	EASY ("easy", "domain.model.strategy_ai.SimpleAttackStrategy"),
	HARD ("hard", "domain.model.strategy_ai.AdvancedAttackStrategy");
	
	private final String type;
	private final String className;
	
	private AttackStrategyType(String type, String className) {
		this.type = type;
		this.className = className;
	}
	
	public String getType() { return this.type; }
	public String getClassName() { return this.className; }
}
