package domain.model.strategy_ai;

import domain.model.AI_Useable;
import domain.model.GameBoard;

/**
 * @author Nathan Olmanst r0594509
 */
public class SimpleAttackStrategy implements AttackStrategy {

	private AI_Useable zeeSlagReference;
	
	public SimpleAttackStrategy(AI_Useable zeeSlag) {
		this.zeeSlagReference = zeeSlag;
	}
	
	/**
	 * Super simple ai
	 */
	@Override
	public boolean attackPlayer(GameBoard gameBoard) {
		int lastShotPosition = 0;
		boolean hitAShip = false;
		
		if (lastShotPosition < 100) {
			hitAShip = zeeSlagReference.attackHumanShip(lastShotPosition++);
		}
		return hitAShip;
	}
}
