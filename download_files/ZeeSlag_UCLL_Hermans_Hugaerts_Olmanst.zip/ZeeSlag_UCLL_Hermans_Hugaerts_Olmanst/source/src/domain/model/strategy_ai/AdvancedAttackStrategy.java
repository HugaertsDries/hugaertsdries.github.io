package domain.model.strategy_ai;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import domain.model.AI_Useable;
import domain.model.GameBoard;

/**
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class AdvancedAttackStrategy implements AttackStrategy {

	private AI_Useable zeeSlagReference;
	private Set<Integer> attackedPositions;
	
	public AdvancedAttackStrategy(AI_Useable zeeSlag) {
		this.attackedPositions = new HashSet<Integer>();
		this.zeeSlagReference = zeeSlag;
	}
	
	private Integer getNextInteger() {
		
		Integer randomTile; 

		randomTile = new Random().nextInt(100);
		while (this.attackedPositions.contains(randomTile)) {
			randomTile = new Random().nextInt(100);
		}
		this.attackedPositions.add(randomTile);
		return randomTile;
	}
	
	/**
	 * Advanced attack ai:
	 * || Hit random tiles
	 */
	@Override
	public boolean attackPlayer(GameBoard gameBoard) {
		return zeeSlagReference.attackHumanShip(getNextInteger());
	}
}
