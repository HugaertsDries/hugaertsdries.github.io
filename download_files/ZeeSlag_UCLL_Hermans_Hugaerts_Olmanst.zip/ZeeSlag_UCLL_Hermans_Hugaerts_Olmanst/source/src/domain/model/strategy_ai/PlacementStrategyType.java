package domain.model.strategy_ai;


/**
 * @author Nathan Olmanst r0594509
 */
public enum PlacementStrategyType {

	EASY ("Easy", "domain.model.strategy_ai.SimplePlacementStrategy"),
	HARD ("Hard", "domain.model.strategy_ai.AdvancedPlacementStrategy");
	
	private final String type;
	private final String className;
	
	private PlacementStrategyType(String type, String className) {
		this.type = type;
		this.className = className;
	}
	
	public String getType() { return this.type; }
	public String getClassName() { return this.className; }
}
