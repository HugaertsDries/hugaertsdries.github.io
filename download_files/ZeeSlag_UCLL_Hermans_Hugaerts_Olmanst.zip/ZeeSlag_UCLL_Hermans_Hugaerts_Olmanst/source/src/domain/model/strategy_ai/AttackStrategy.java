package domain.model.strategy_ai;

import domain.model.GameBoard;

/**
 * @author Cedric hermans r0449493
 */
public interface AttackStrategy {
	public boolean attackPlayer(GameBoard gameBoard);
}
