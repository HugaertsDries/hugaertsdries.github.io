package domain.model.strategy_ai;

import java.lang.reflect.Constructor;

import domain.model.AI_Useable;
import domain.model.ModelException;

/**
 * @author Cedric Hermans r0449493
 * @author Nathan Olmanst r0594509
 */
public class AttackStrategyFactory {

	/**
	 * @param strategyType
	 * @param arg reference to be given to the attackStrategies. arg needs to implement AI_Useable!!
	 * @return and instance of class AttackStrategy
	 */
	public static AttackStrategy createStrategy(String strategyType, Object... args) {
		
		AttackStrategy instance = null;
		
		try{
			Class<?> aClass = Class.forName(strategyType);
			Constructor<?> constructor = aClass.getConstructor(AI_Useable.class);
			instance = (AttackStrategy)constructor.newInstance(args);
		}
		catch (Exception ex){
			throw new ModelException(ex.getMessage(), ex);
		}
		return instance;
	}
}
