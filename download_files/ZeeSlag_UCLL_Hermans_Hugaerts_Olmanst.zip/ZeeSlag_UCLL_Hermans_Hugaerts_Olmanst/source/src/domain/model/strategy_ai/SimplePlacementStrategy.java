package domain.model.strategy_ai;

import java.util.Random;

import domain.model.Alignment;
import domain.model.GameBoard;
import domain.model.ModelException;
import domain.model.ShipTypes;

/**
 * @author Nathan Olmanst r0594509
 */
public class SimplePlacementStrategy implements PlacementStrategy {

	private Random randomAlignement = new Random();
	

	@Override
	public void placeShips(GameBoard gameBoard) {
		int counter = 0;
		int index = 0;
		
		while (counter < 5) {
			ShipTypes ship = ShipTypes.getRandom();
			
			int numberPosition;
			if (index < 100) {
				numberPosition = index;
				index++;
			} else throw new IllegalAccessError("Fatal error AI placement");
			
			boolean isHorizontal = randomAlignement.nextBoolean();

			try {
				gameBoard.placeShipAtIndex(numberPosition, ship,
						isHorizontal ? Alignment.HORIZONTAL : Alignment.VERTICAL);
				counter++;
			} catch (ModelException me) {
				// REPEAT WHILE LUS
			}
		}
	}
}
