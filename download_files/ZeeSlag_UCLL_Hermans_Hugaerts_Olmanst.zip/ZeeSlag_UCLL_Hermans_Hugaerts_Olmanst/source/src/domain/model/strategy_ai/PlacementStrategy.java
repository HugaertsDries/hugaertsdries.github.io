package domain.model.strategy_ai;

import domain.model.GameBoard;

/**
 * @author Cedric Hermans r0449493
 */
public interface PlacementStrategy {
	public void placeShips(GameBoard gameBoad);
}
