package domain.model;

/**
 * Used by the game to reach the UI
 */
public class EndGameException extends ModelException {

	private static final long serialVersionUID = 1L;

	public EndGameException(String message) {
		super(message);
	}
}
