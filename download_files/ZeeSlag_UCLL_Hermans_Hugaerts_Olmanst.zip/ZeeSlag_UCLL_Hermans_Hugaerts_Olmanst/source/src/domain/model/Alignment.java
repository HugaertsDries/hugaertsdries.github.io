package domain.model;

/**
 * @author Nathan Olmanst r0594509
 * @author Dries Hugaerts r0629197
 */
public enum Alignment {

	HORIZONTAL ("Horizontaal", "H", 10),
	VERTICAL ("Verticaal", "V", 1);
	
	
	private final String NAME;
	private final String ABBREVIATION;
	private final int MULTIPLIER;
	
	private Alignment(String name, String abbreviation, int multiplier) {
		this.NAME = name;
		this.ABBREVIATION = abbreviation;
		this.MULTIPLIER = multiplier;
	}
	
	public String toString() {
		return this.NAME;
	}
	
	public String getAbbreviation(){
		return this.ABBREVIATION;
	}
	
	public int getMultiplier() {
		return this.MULTIPLIER;
	}
	
}
