package domain.model.launcher;

import java.io.IOException;

import domain.controller.Controller;

/**
 * @author Dries Hugaerts r0629197
 */
public class ZeeSlagLauncher {
	
	public static void main(String[] args) throws IOException {

		Controller controller = new Controller();
		controller.startGame();
	}
}