package domain.model;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.border.LineBorder;

/**
 * @author Nathan Olmanst r0594509
 * 
 * @info Class defining a game tile
 */
public class BoardTile extends JButton {

	private static final long serialVersionUID = 1L;
	private int[] position;
	private boolean isOccupied;
	private boolean isHit;
	
	/**
	 * Creates a white button (game tile) of dimention (35/35) that responds to a mouse click.
	 * 
	 * @param buttonString defines the name to be displayed on the button.
	 * @param position keeps track of the position of this button in the grid layout.
	 */
	public BoardTile(String buttonString, int[] position) {
		this(buttonString, position, 35, Color.WHITE);
	}
	
	/**
	 * Creates a button (game tile) that responds to a mouse click.
	 * 
	 * @param buttonString defines the name to be displayed on the button.
	 * @param position keeps track of the position of this button in the grid layout.
	 * @param sideLength defines the size of the square button.
	 * @param colour defines the colour of this button.
	 */
	public BoardTile(String buttonString, int[] position, int sideLength, Color colour) {
		super(buttonString);
		
		this.position = position;
		this.setPreferredSize(new Dimension(sideLength, sideLength));
		this.setBackground(colour);
		this.isOccupied = false;
		this.isHit = false;
	}
	
	public void setOccupation(boolean state) {
		this.isOccupied = state;
	}
	
	public boolean isOccupied() {
		return this.isOccupied;
	}
	
	public int[] getPosition() {
		return this.position;
	}
	
	
	public boolean isHit() {
		return this.isHit;
	}
	
	// ============================================================ LOGIC
	// ================================================================
	
	/**
	 * Changes the colour of both the background as well as the border of this button / tile
	 */
	public void changeHitColour(Color colour) {
		this.setBackground(colour);
		this.setBorder(new LineBorder(colour));
	}
	
	/**
	 * Changes the colour of the background while keeping the default border colour
	 * Should be used for everything but ships.
	 */
	public void changeMissColour(Color colour) {
		this.setBackground(colour);
	}
	
	/**
	 * Set this tile to 'occupied' and change it's colour
	 */
	public void placeShip(boolean visibility) {
		if (visibility)
			this.changeHitColour(Color.GRAY);
		
		this.setOccupation(true);
	}
	
	/**
	 * Check whether this tile is occupied or not and change the colour and this.isHit variable accordingly
	 */
	public boolean attackTile() {
		if (isOccupied) {
			this.changeHitColour(Color.YELLOW);
			this.isHit = true;
			this.removeActionListener(this.getActionListeners()[0]);
			return true;
		} else {
			this.changeMissColour(new Color(153, 204, 255));
			this.removeActionListener(this.getActionListeners()[0]);
			return false;
		}
	}
	
	public void sinkShip() {
		this.changeHitColour(Color.RED);
	}
	
	@Override
	public String toString() {
		return "Button at Position(" + this.getPosition()[0] + ", " + this.getPosition()[1] + "): is " + 
				(this.isOccupied()? "occupied" : "unoccupied");
	}
	
}
