package domain.model;

/**
 * @author Dries Hugaerts r0629197
 */
public class Properties {

	private ShipTypes ship;
	private Alignment alignment;
	
	public Properties() {
		this.setShip(ShipTypes.CARRIER);
		this.setAlignment(Alignment.HORIZONTAL);
	}
	
	public Properties(ShipTypes type, Alignment alignment){
		this.setShip(type);
		this.setAlignment(alignment);
	}

	public ShipTypes getShip() {
		return ship;
	}

	public void setShip(ShipTypes ship) {
		this.ship = ship;
	}

	public Alignment getAlignment() {
		return alignment;
	}

	public void setAlignment(Alignment alignment) {
		this.alignment = alignment;
	}
}
