package domain.model;

/**
 * @author Nathan Olmanst r0594509
 * 
 * @info Interface used to provide only the the needed methods to the AI's strategies
 */
public interface AI_Useable {

	public boolean attackHumanShip(int tileIndex) throws ModelException; 
}
