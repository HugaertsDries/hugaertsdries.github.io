package domain.model.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

/**
 * @author Cedric Hermans r0449493
 * @author Nathan Olmanst r0594509
 */
public class FileStorage implements DataStorage {

	private final static FileStorage FILESTORAGE_INSTANCE = new FileStorage();
	private Properties properties;
	private InputStream inputStream;
	private File propertiesFile = null;

	private FileStorage() {
		properties = new Properties();

		try {
			propertiesFile = new File(new File(".").getCanonicalFile() + "/GameStrategy.properties");
			inputStream = new FileInputStream(propertiesFile);
			properties.load(inputStream);
		} catch (IOException e) {
			try { createNewPropertiesFile();
			} catch (IOException e1) {}
		} finally {
			try {
				inputStream = new FileInputStream(propertiesFile);
				properties.load(inputStream);
			} catch (IOException e) {}
		}
	}

	public static FileStorage getInstance() {
		return FILESTORAGE_INSTANCE;
	}

	@Override
	public String load(String propertyName) {
		Object property = properties.getProperty(propertyName);
		return (String) property;
	}

	@Override
	public void store(String propertyName, String property) {
		properties.setProperty(propertyName, property);
		try {
			FileOutputStream outputStream = new FileOutputStream(propertiesFile);
			properties.store(outputStream, "This are the AI strategies.");
			outputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void createNewPropertiesFile() throws IOException {
		PrintWriter pw = null;

		propertiesFile.getParentFile().mkdirs();

		propertiesFile.createNewFile();

		// PrintWriter
		pw = new PrintWriter(propertiesFile);

		pw.println("#This are the AI strategies.");
		pw.println("#Newly created file");
		pw.println("attackStrategy=Easy");
		pw.println("placeStrategy=Hard");
		pw.flush();
		pw.close();

		inputStream = new FileInputStream(propertiesFile);
		properties.load(inputStream);
	}
}
