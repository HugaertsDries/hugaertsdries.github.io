package domain.model.service;

/**
 * @author Nathan Olmanst r0594509 
 * 
 * Interface for storing and loading data
 */
public interface DataStorage {

	public String load(String propertyName);
	public void store(String propertyName, String property);
}
