package domain.model;

/**
 * @author Dries Hugaerts r0629197
 */
public interface Subject {
	
	public void notifyObservers();
	
	public void notifyObserver();

	public void registerObserver(Observer o);
	
}
