package domain.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Nathan Olmanst r0594509
 */
public class Ship implements Subject {

	private List<BoardTile> tiles;
	private List<Observer> observers;
	private Properties properties;
	private boolean isSunken = false;

	public Ship(List<BoardTile> tiles, Properties properties, Boolean visibility) {
		this.setTiles(tiles);
		this.setTilesTaken(visibility);
		this.setProperties(properties);
		observers = new ArrayList<>();
	}

	private void setProperties(Properties properties) {
		if (properties == null) {
			throw new ModelException("Properties cannot be null", null);
		}
		this.properties = properties;
	}

	private void setTiles(List<BoardTile> tiles) {
		if (tiles == null || tiles.isEmpty()) {
			throw new ModelException("The tiles may not be empty or null", null);
		}
		this.tiles = tiles;
	}

	private void setTilesTaken(Boolean v) {
		for (BoardTile b : this.tiles) {
			b.placeShip(v);
		}
	}

	public boolean getSunkenState() {
		return this.isSunken;
	}
	
	public void isSunken() {
		if (this.isSunken == false) {
			boolean isSunken = true;
			for (BoardTile b : this.tiles) {
				
				if (!b.isHit()) {
					isSunken = false;
				}
			}
			this.isSunken = isSunken;
			this.notifyObservers();
		}
	}

	public List<BoardTile> getTiles() {
		return this.tiles;
	}

	public Properties getProperties() {
		return this.properties;
	}

	@Override
	public void notifyObservers() {
		if (this.isSunken == true) {
			for (Observer o : this.observers) {
				o.update(this);
			}
		}
	}

	@Override
	public void registerObserver(Observer o) {
		if (o == null) {
			throw new ModelException("Observer cannot be null", null);
		}

		this.observers.add(o);
	}

	@Override
	public void notifyObserver() {
		// TODO Auto-generated method stub

	}
}
