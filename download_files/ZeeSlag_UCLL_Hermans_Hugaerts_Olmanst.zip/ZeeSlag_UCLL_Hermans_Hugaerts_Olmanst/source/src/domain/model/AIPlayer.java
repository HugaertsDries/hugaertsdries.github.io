package domain.model;

import domain.model.strategy_ai.AttackStrategy;
import domain.model.strategy_ai.PlacementStrategy;
import domain.model.strategy_ai.SimpleAttackStrategy;
import domain.model.strategy_ai.SimplePlacementStrategy;
/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 */
public class AIPlayer extends Player {

	/**
	 * Inherited instance variables:
	 * 
	 * private String name; private GameBoard association;
	 * 
	 */
	private PlacementStrategy placementStrategy;
	private AttackStrategy attackStrategy;

	/**
	 * Setup an AI with default simple attack and placement strategies
	 */
	public AIPlayer(String name, AI_Useable zeeSlagReference) {
		super(name);

		this.placementStrategy = new SimplePlacementStrategy();
		this.attackStrategy = new SimpleAttackStrategy(zeeSlagReference);
	}
	
	public void setUp() {
		placeShips();
	}
	
	public void setNewPlacementStrategy(PlacementStrategy strategy) {
		this.placementStrategy = strategy;
	}
	
	public void setNewAttacktStrategy(AttackStrategy strategy) {
		this.attackStrategy = strategy;
	}

	/**
	 * Generate random values and call Gameboard ship placement algorithm to place the ships
	 */
	public void placeShips() {
		placementStrategy.placeShips(super.gameBoard);
	}
	
	public boolean attackHumanPlayer() {
		return attackStrategy.attackPlayer(super.gameBoard);
	}
}
