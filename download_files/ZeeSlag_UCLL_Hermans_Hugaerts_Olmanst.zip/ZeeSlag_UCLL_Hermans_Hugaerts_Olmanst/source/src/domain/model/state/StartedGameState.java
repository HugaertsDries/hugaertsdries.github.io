package domain.model.state;

import domain.model.AIPlayer;
import domain.model.BoardTile;
import domain.model.EndGameException;
import domain.model.ModelException;
import domain.model.ZeeSlag;

/**
 * @author Nathan Olmanst r0594509
 */
public class StartedGameState implements GameState {

	private ZeeSlag game;
	
	public StartedGameState(ZeeSlag game) {
		this.game = game;
	}
	
	@Override
	public void endGame() {
		game.setCurrentState(game.getEndedState());
		game.revealBoards();
	}

	@Override
	public void placeShip(BoardTile tile) {
		throw new ModelException("Cannot place ships after the game has started", null);
	}

	/**
	 *  Carries over the UI's request to attack a tile +
	 *  || Makes the AI shoot once +
	 *  || Checks if the game-ending conditions are met.
	 */
	@Override
	public void attackShip(BoardTile tile) {
		
		// Carry over UI's request to attack a tile
		if (this.game.getAiGameBoard().attackShip(tile)) {
			this.game.getAiGameBoard().getPlayer().lowerPlayerScore();
		}
		
		// Make the AI attack a tile
		if (((AIPlayer) this.game.getAiGameBoard().getPlayer()).attackHumanPlayer()) {
			this.game.getHumanGameBoard().getPlayer().lowerPlayerScore();
		}
		
		// Check if the game-ending conditions are met.
		if (this.game.getAiGameBoard().areShipsSunken() ) {
			this.game.getCurrentState().endGame();
			throw new EndGameException("Player " + this.game.getHumanGameBoard().getPlayer().getName() + " won the game with " + this.game.getHumanScore() + " points.");	
		} else if (this.game.getHumanGameBoard().areShipsSunken()) {
			this.game.getCurrentState().endGame();
			throw new EndGameException("Player " + this.game.getAiGameBoard().getPlayer().getName() + " won the game with " + this.game.getAiScore() + " points.");
		}
	}

	@Override
	public void setStrategies(String attackStrategy, String placementStrategy) {
		throw new ModelException("Cannot change the AI's behaviour after the game has started", null);
	}
}
