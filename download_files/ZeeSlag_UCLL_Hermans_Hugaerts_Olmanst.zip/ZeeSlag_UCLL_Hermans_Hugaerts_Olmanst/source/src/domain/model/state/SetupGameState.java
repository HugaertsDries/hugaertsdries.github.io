package domain.model.state;

import domain.model.AIPlayer;
import domain.model.BoardTile;
import domain.model.ZeeSlag;
import domain.model.service.FileStorage;
import domain.model.strategy_ai.AttackStrategy;
import domain.model.strategy_ai.AttackStrategyFactory;
import domain.model.strategy_ai.AttackStrategyType;
import domain.model.strategy_ai.PlacementStrategy;
import domain.model.strategy_ai.PlacementStrategyFactory;
import domain.model.strategy_ai.PlacementStrategyType;
import domain.model.ModelException;

/**
 * @author Nathan Olmanst r0594509
 */
public class SetupGameState implements GameState {

	private ZeeSlag game;
	
	public SetupGameState(ZeeSlag game) {
		this.game = game;
	}
	
	@Override
	public void startGame() {
		game.setCurrentState(game.getStartedState());
		this.game.startAI();
	}

	@Override
	public void placeShip(BoardTile tile) {
		try {
			this.game.getHumanGameBoard().humanPlaceShip(tile, this.game.getProperties().getShip(), this.game.getProperties().getAlignment());
		} catch (Exception e) {
			throw new ModelException(e.getMessage(), e);
		}
	}

	@Override
	public void attackShip(BoardTile tile) {
		throw new ModelException("Cannot attack ships if you have not started the game yet.", null);
	}

	@Override
	public void setStrategies(String attackStrategy, String placementStrategy) {
		
		PlacementStrategy placementStrat = PlacementStrategyFactory.createStrategy(PlacementStrategyType.valueOf(placementStrategy.toUpperCase()).getClassName());
		AttackStrategy attackStrat = AttackStrategyFactory.createStrategy(AttackStrategyType.valueOf(attackStrategy.toUpperCase()).getClassName(), this.game);
			
		((AIPlayer) this.game.getAiGameBoard().getPlayer()).setNewPlacementStrategy(placementStrat);
		((AIPlayer) this.game.getAiGameBoard().getPlayer()).setNewAttacktStrategy(attackStrat);
				
		FileStorage.getInstance().store("attackStrategy", attackStrategy);
		FileStorage.getInstance().store("placeStrategy", placementStrategy);
	}
}
