package domain.model.state;

import domain.model.BoardTile;
import domain.model.ModelException;

/**
 * @author Nathan Olmanst r0594509
 */
public interface GameState {

	default public void setupGame() {
		throw new ModelException("Cannot change state to 'SetupGameState'", null);
	}

	default public void startGame() {
		throw new ModelException("Cannot change state to 'StartedGameState'", null);
	}
	
	default public void endGame() {
		throw new ModelException("Cannot change state to 'EndedGameState'", null);
	}
	
	public void placeShip(BoardTile tile);
	
	public void attackShip(BoardTile tile);
	
	public void setStrategies(String attackStrategy, String placementStrategy);
}
