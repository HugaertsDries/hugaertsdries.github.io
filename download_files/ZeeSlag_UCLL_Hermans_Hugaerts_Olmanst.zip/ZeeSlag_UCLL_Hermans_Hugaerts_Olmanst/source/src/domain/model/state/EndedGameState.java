package domain.model.state;

import domain.model.BoardTile;
import domain.model.ModelException;
import domain.model.ZeeSlag;

/**
 * @author Nathan Olmanst r0594509
 */
public class EndedGameState implements GameState {

	private ZeeSlag game;
	
	public EndedGameState(ZeeSlag zeeSlag) {
		this.game = zeeSlag;
	}
	
	@Override
	public void setupGame() {
		game.setCurrentState(game.getSetupState());
		
		this.game.getAiGameBoard().getPlayer().ResetPlayer();
		this.game.getAiGameBoard().resetGameBoard();
		this.game.getHumanGameBoard().getPlayer().ResetPlayer();
		this.game.getHumanGameBoard().resetGameBoard();
	}
	
	@Override
	public void placeShip(BoardTile tile) {
		throw new ModelException("Game is over", null);
	}

	@Override
	public void attackShip(BoardTile tile) {
		throw new ModelException("Game is over", null);
	}

	@Override
	public void setStrategies(String attackStrategy, String placementStrategy) {
		throw new ModelException("Game is over", null);
	}

}
