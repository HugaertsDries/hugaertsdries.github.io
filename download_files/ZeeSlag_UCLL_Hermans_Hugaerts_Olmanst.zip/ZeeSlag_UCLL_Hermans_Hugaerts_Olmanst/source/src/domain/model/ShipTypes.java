package domain.model;

/**
 * @author Nathan Olmanst r0594509
 */
public enum ShipTypes {
	
	CARRIER ("Carrier", 5, 1),
	BATTLESHIP ("Battleship", 4, 2),
	SUBMARINE ("Submarine", 3, 3),
	DESTROYER ("Destroyer", 3, 3),
	PATROL_SHIP ("Patrol_Ship", 2, 4);
	
	
	private final String NAME;
	private final int LENGTH;
	private final int MAX_AMOUNT;
	private int countHumanPlayer;
	private int countAIPlayer;
	
	private ShipTypes(String name, int length, int max_amount) {
		this.NAME = name;
		this.LENGTH = length;
		this.MAX_AMOUNT = max_amount;
		this.countAIPlayer = 0;
		this.countHumanPlayer = 0;
	}
	
	public String toString() {
		return NAME;
	}
	
	public int getLength() {
		return this.LENGTH;
	}
	
	public int getMaxAmount() {
		return this.MAX_AMOUNT;
	}
	
	public static ShipTypes getRandom() {
		return values()[(int) (Math.random() * values().length)];
	}
	
	public int getCountHumanPlayer() {
		return countHumanPlayer;
	}
	
	public void incrementCountHumanPlayer() {
		countHumanPlayer++;
	}
	
	public int getCountAIPlayer() {
		return countAIPlayer;
	}
	
	public void incrementCountAIPlayer() {
		countAIPlayer++;
	}
	
	public void reset(){
		this.countAIPlayer = 0;
		this.countHumanPlayer = 0;
	}
}
