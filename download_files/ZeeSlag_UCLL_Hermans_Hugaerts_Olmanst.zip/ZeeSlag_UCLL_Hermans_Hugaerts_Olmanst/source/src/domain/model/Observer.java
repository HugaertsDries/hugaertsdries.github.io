package domain.model;

/**
 * @author Dries Hugaerts r0629197
 */
public interface Observer {

	public void update(Subject s);
}
