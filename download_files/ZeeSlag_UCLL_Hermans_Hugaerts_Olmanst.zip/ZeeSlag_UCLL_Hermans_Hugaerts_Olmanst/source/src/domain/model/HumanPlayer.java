package domain.model;

/**
 * @author Dries Hugaerts r0629197
 */
/**
 * @author Cedric Hermans r0449493
 * 
 * @info Defines a human player who can place his own ships on his own board, and guess the location of ships on the AI's board.
 */
public class HumanPlayer extends Player {

	public HumanPlayer(String name) {
		super(name);
	}
}
