package domain.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Cedric Hermans r0449493
 * @author Dries Hugaerts r0629197
 * @author Nathan Olmanst r0594509
 */
public class GameBoard implements Observer {

	private List<BoardTile> buttons;
	private List<Ship> ships;
	private Player player;
	private int remainingShipsToPlace = 5;

	public GameBoard(Player player) {
		generateButtons();
		setPlayer(player);
		this.player.setDoubleAssociation(this);
		this.ships = new ArrayList<>();
	}

	public void resetGameBoard() {
		this.remainingShipsToPlace = 5;
		this.ships = new ArrayList<>();
		generateButtons();
	}
	
	public int getRemainingShipsToPlace(){
		return this.remainingShipsToPlace;
	}
	
	
	private void generateButtons() {

		this.buttons = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				BoardTile b = new BoardTile("", new int[] { i, j }, 35, Color.WHITE);
				this.buttons.add(b);
			}
		}
	}

	private void setPlayer(Player player) {
		this.player = player;
	}

	public Player getPlayer() {
		return this.player;
	}

	public List<BoardTile> getbuttons() {
		return this.buttons;
	}

	public boolean areShipsSunken() {
		for(Ship s : this.ships){
			if (!s.getSunkenState()) {
				return false;
			}
		}
		return true;
	}
	
	// ============================================================ LOGIC
	// ================================================================

	public boolean attackShip(BoardTile tile) {
		int i = tile.getPosition()[0] * 10 + tile.getPosition()[1];
		boolean result = buttons.get(i).attackTile();
		
		if (result) 
			this.checkForSunkenShips();
		
		return result;
	}

	/**
	 * Called by actionListener when player presses a button on his own board
	 */
	public void humanPlaceShip(BoardTile tile, ShipTypes ship, Alignment alignment) throws ModelException {
		if (remainingShipsToPlace <= 0)
			throw new ModelException("Only a maximum of 5 ships can be placed.", null);
		if (ship.getCountHumanPlayer() >= ship.getMaxAmount())
			throw new ModelException(ship.name() + " can only be placed " + ship.getMaxAmount() + " times.", null);

		this.placeShip(tile, ship, alignment);
	}

	/**
	 * Called by AIplayer to place his ships on his board
	 */
	public void placeShipAtIndex(int shipIndex, ShipTypes ship, Alignment alignment) throws ModelException {
		if (remainingShipsToPlace <= 0)
			throw new ModelException("Only a maximum of 5 ships can be placed.", null);
		if (ship.getCountAIPlayer() >= ship.getMaxAmount())
			throw new ModelException("This ship can only be placed ... times.", null);

		/**
		 * Make create a tile object for the placeShip method
		 */
		BoardTile tile = this.buttons.get(shipIndex);

		this.placeShip(tile, ship, alignment);
	}

	/**
	 * Places a ship on the gameboard based on it's alignment and type.
	 * 
	 * @throws ModelException
	 *             when the ship's position is invalid
	 */
	private void placeShip(BoardTile tile, ShipTypes ship, Alignment alignment) throws ModelException {

		int intitialTileIndex = tile.getPosition()[0] * 10 + tile.getPosition()[1];

		if (!isValidShipPlacement(intitialTileIndex, ship, alignment)) {
			throw new ModelException("Invalid ship placement", null);
		}

		/**
		 * Use multiplier value to iterate horizontally or vertically
		 */
		ArrayList<BoardTile> tiles = new ArrayList<>();
		for (int i = intitialTileIndex; i < intitialTileIndex
				+ (ship.getLength() * alignment.getMultiplier()); i += alignment.getMultiplier()) {
			//buttons.get(i).PlaceShip(this.player instanceof HumanPlayer ? true : false);
			tiles.add(this.buttons.get(i));
		}
		
		Properties p = new Properties( ship, alignment);
		Ship s = new Ship(tiles, p, this.player instanceof HumanPlayer ? true : false );
		s.registerObserver(this);
		this.ships.add(s);
		
		/**
		 * Update player counters
		 */
		if (this.player instanceof HumanPlayer) {
			ship.incrementCountHumanPlayer();
		} else {
			ship.incrementCountAIPlayer();
		}
		remainingShipsToPlace--;
	}

	private boolean isValidShipPlacement(int shipCoordinates, ShipTypes shipType, Alignment shipAlignment) {

		/**
		 * Ship can't overflow at the bottom or right side of the board
		 */
		if (!isValidBoardPlacement(shipCoordinates, shipType, shipAlignment)) {
			return false;
		}

		/**
		 * Ship needs space around itself
		 */
		if (!shipHasSpace(shipCoordinates, shipType, shipAlignment)) {
			return false;
		}

		return true;
	}

	/**
	 * Checks if the to places ship has at least one tile space around itself
	 *
	 * || Make a loop for every lane that has to be checked (ship location, left
	 * of ship and right of ship) || Start to iterate 1 position IN FRONT of
	 * ship || Iterate over the lanes for a length of shipLengh + 2 (need to
	 * make sure there is room in FRONT and BEHIND as well
	 */
	private boolean shipHasSpace(int shipCoordinates, ShipTypes shipType, Alignment shipAlignment) {

		int loopStart = 0;
		int loopEnd = 3;
		int extraLength = 2;
		
		//Amount to modify index with to get side lanes
		int modifier = shipAlignment.equals(Alignment.HORIZONTAL) ? -1 : -10;
		
		//Start in Front of ship
		int startIndex = shipCoordinates - shipAlignment.getMultiplier();
		int endIndex = startIndex + shipType.getLength() * shipAlignment.getMultiplier();

		if (shipAlignment.equals(Alignment.HORIZONTAL)) {
			if (shipCoordinates % 10 == 0) {			//skip first loop
				loopStart = 1;
				modifier += shipAlignment.equals(Alignment.HORIZONTAL) ? 1 : 10;
			}
			if (shipCoordinates % 10 == 9) {			// skip last loop
				loopEnd = 2;
			}
		} else if (shipAlignment.equals(Alignment.VERTICAL)){
			if (shipCoordinates % 10 == 0) {			//don't check in front of ship
				startIndex += shipAlignment.getMultiplier();
				extraLength = 1;
			}
			if (endIndex % 10 == 9) {					//don't check begind the ship
				extraLength = 1;
			}
		}
		
		for (int counter = loopStart; counter < loopEnd; counter++) {
			int laneIndex = (startIndex + modifier);

			for (int i = laneIndex; i < laneIndex + (shipType.getLength() + extraLength) * shipAlignment.getMultiplier(); i += shipAlignment.getMultiplier()) {
				if (i >= 0 && i < 100 && buttons.get(i).isOccupied()) {
					return false;
				}
			}
			modifier += shipAlignment.equals(Alignment.HORIZONTAL) ? 1 : 10;
		}
		return true;
	}

	private boolean isValidBoardPlacement(int shipCoordinates, ShipTypes shipType, Alignment shipAlignment) {

		if (shipAlignment.equals(Alignment.VERTICAL)) {
			if (shipCoordinates + (shipType.getLength() * shipAlignment.getMultiplier()) > shipCoordinates
					- shipCoordinates % 10 + 10) {
				return false;
			}
		} else {
			if (shipCoordinates + (shipType.getLength() * shipAlignment.getMultiplier())
					- 10 /* starts at 0 */ > 99) {
				return false;
			}
		}
		return true;
	}
	
	private void checkForSunkenShips() {
		for(Ship s : this.ships){
			s.isSunken();
		}
	}
	
	@Override
	public void update(Subject s) {
		Ship ship = (Ship) s;
		ArrayList<BoardTile> tiles = (ArrayList<BoardTile>) ship.getTiles();
		for(BoardTile b : tiles ){
			b.sinkShip();
		}
		//System.out.println(ship.getProperties().getShip() + " Is Gezonken!!");
	}

	public void revealBoard() {
		for (BoardTile tile : this.buttons) {
			if (tile.isOccupied() && !tile.isHit()) {
				tile.changeHitColour(Color.DARK_GRAY);
			}
		}
	}
}